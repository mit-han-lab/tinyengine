/* Automatically generated source file */
#include <float.h>
#include <tinyengine_function.h>
#include <tinyengine_function_fp.h>

#include "genNN.h"
#include "genModel.h"
#include "genInclude.h"

/* Variables used by all ops */
ADD_params add_params;
int i;
int8_t *int8ptr,*int8ptr2;
int32_t *int32ptr;
float *fptr,*fptr2,*fptr3;

signed char* getInput() {
    return &buffer0[15376];
}
signed char* getOutput() {
    return NNoutput;
}
void end2endinference(q7_t* img){
    //stage 1
    int i, j, h, w, c;
    for (i = 0; i < 4; i++){
        uint16_t pad_t=0,pad_b=0;
        if (i == 0){
            pad_t = 7;
        }
        else if (i == 3){
            pad_b = 0;
        }
        for (j = 0; j < 4; j++){
            uint16_t pad_l=0,pad_r=0;
            if (j == 0){
                pad_l = 7;
            }
            else if (j == 3){
                pad_r = 0;
            }
            /* load partial input from the img */
            q7_t* patch_input = getInput(); // for partial input
            int start_x = TN_MAX(56 * j - 7,0);
            int start_y = TN_MAX(56 * i - 7,0);
            q7_t* img_ptr = &img[(start_x + start_y * 224) * 3];

            //skip top
            patch_input += pad_t * 63 * 3;
            for (h = pad_t; h < 63 - pad_b; h++){
                //skip left
                patch_input += pad_l * 3;
                //fill middle
                int bytes = (63 - (pad_l + pad_r)) * 3;
                memcpy (patch_input, img_ptr, bytes);
                img_ptr += 224 * 3;
                patch_input += bytes;
                //skip right
                patch_input += pad_r * 3;
            }
            invoke_1patch(pad_t,pad_b,pad_l,pad_r);
            /* concat the output from buffer0 (this is set manually for now) */
            q7_t* output_ptr = &buffer0[376320];;
            q7_t* patch_output = &buffer0[439040];
            for (h = 0; h < 7; h++){
                for (w = 0; w < 7; w++){
                    for (c = 0; c < 40; c++){
                        int output_idx = ((w + j * 7) + (h + i * 7) * 28) * 40 + c;;
                        output_ptr[output_idx] = patch_output[(w + h * 7) * 40 + c];
                    }
                }
            }
        }
    }
    //stage 2
    invoke(NULL);
}

void invoke_1patch(uint16_t pad_t, uint16_t pad_b, uint16_t pad_l ,uint16_t pad_r){
/* layer 0:CONV_2D */
patchpadding_convolve_s8_kernel3_inputch3_stride2(&buffer0[15376],63,63,3,(const q7_t*) weight0,bias0,shift0,multiplier0,-128,128,-128,127,&buffer0[0],31,31,16,sbuf,kbuf,-128, pad_t, pad_b, pad_l, pad_r);
pad_t /= 2;pad_b /= 2;pad_l /= 2;pad_r /= 2;
/* layer 1:CONV_2D */
convolve_1x1_s8_ch16_fpreq(&buffer0[0],31,31,16,(const q7_t*) weight1,bias1,scales1,-7,128,-128,127,&buffer0[92256],31,31,16,sbuf);
/* layer 2:CONV_2D */
convolve_1x1_s8_ch16_fpreq(&buffer0[92256],31,31,16,(const q7_t*) weight2,bias2,scales2,-128,7,-128,127,&buffer0[0],31,31,96,sbuf);
/* layer 3:DEPTHWISE_CONV_2D */
patchpadding_depthwise_kernel3x3_stride2_inplace_CHW(&buffer0[0],31,31,96,(const q7_t*) CHWweight3,offsetBias3,offsetRBias3,shift3,multiplier3,-128,128,-128,127,&buffer0[0],15,15,96,sbuf,-128, pad_t, pad_b, pad_l, pad_r);
pad_t /= 2;pad_b /= 2;pad_l /= 2;pad_r /= 2;
/* layer 4:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[0],15,15,96,(const q7_t*) weight4,bias4,scales4,7,128,-128,127,&buffer0[23064],15,15,24,sbuf);
/* layer 5:CONV_2D */
convolve_1x1_s8_ch24_fpreq(&buffer0[23064],15,15,24,(const q7_t*) weight5,bias5,scales5,-128,-7,-128,127,&buffer0[0],15,15,96,sbuf);
/* layer 6:DEPTHWISE_CONV_2D */
patchpadding_depthwise_kernel3x3_stride2_inplace_CHW(&buffer0[0],15,15,96,(const q7_t*) CHWweight6,offsetBias6,offsetRBias6,shift6,multiplier6,-128,128,-128,127,&buffer0[0],7,7,96,sbuf,-128, pad_t, pad_b, pad_l, pad_r);
pad_t /= 2;pad_b /= 2;pad_l /= 2;pad_r /= 2;
/* layer 7:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[0],7,7,96,(const q7_t*) weight7,bias7,scales7,12,128,-128,127,&buffer0[439040],7,7,40,sbuf);
}

void invoke(float* labels){
/* layer 0:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[376320],28,28,40,(const q7_t*) weight8,bias8,scales8,-128,-12,-128,127,&buffer0[0],28,28,240,sbuf);
/* layer 1:DEPTHWISE_CONV_2D */
depthwise_kernel5x5_stride1_inplace_CHW_fpreq(&buffer0[0],28,28,240,(const q7_t*) CHWweight9,offsetBias9,offsetRBias9,scales9,-128,128,-128,127,&buffer0[0],28,28,240,sbuf,-128);
/* layer 2:AVERAGE_POOL_2D */
avg_pooling(&buffer0[0],28,240,28,1,1,1,1,-128,127,&buffer0[188160]);
/* layer 3:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[188160],1,1,240,(const q7_t*) weight10,bias10,scales10,-128,128,-128,127,&buffer0[188400],1,1,10,sbuf);
/* layer 4:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[188400],1,1,10,(const q7_t*) weight11,bias11,scales11,1,128,-128,127,&buffer0[407680],1,1,240,sbuf);
/* layer 5:SE_ELEMENT_MULT_2D */
element_mult_nx1(&buffer0[0],28,28,240,&buffer0[407680],-128,1,-128,-127,128,0.005417971688058868,&buffer0[188160]);
/* layer 6:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[188160],28,28,240,(const q7_t*) weight12,bias12,scales12,-43,128,-128,127,&buffer0[0],28,28,40,sbuf);
/* layer 7:ADD */
add_fpreq(31360, &buffer0[0],1.1920928955078125e-07,-43,&buffer0[439040],2.2415974854084197e-06,12,2.241683887405088e-06,12,&buffer0[407680]);
/* layer 8:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[407680],28,28,40,(const q7_t*) weight13,bias13,scales13,-128,-12,-128,127,&buffer0[0],28,28,240,sbuf);
/* layer 9:DEPTHWISE_CONV_2D */
depthwise_kernel5x5_stride1_inplace_CHW_fpreq(&buffer0[0],28,28,240,(const q7_t*) CHWweight14,offsetBias14,offsetRBias14,scales14,-128,128,-128,127,&buffer0[0],28,28,240,sbuf,-128);
/* layer 10:AVERAGE_POOL_2D */
avg_pooling(&buffer0[0],28,240,28,1,1,1,1,-128,127,&buffer0[188160]);
/* layer 11:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[188160],1,1,240,(const q7_t*) weight15,bias15,scales15,-128,128,-128,127,&buffer0[188400],1,1,10,sbuf);
/* layer 12:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[188400],1,1,10,(const q7_t*) weight16,bias16,scales16,2,128,-128,127,&buffer0[439040],1,1,240,sbuf);
/* layer 13:SE_ELEMENT_MULT_2D */
element_mult_nx1(&buffer0[0],28,28,240,&buffer0[439040],-128,2,-128,-127,128,0.005336839015708832,&buffer0[188160]);
/* layer 14:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[188160],28,28,240,(const q7_t*) weight17,bias17,scales17,-40,128,-128,127,&buffer0[0],28,28,40,sbuf);
/* layer 15:ADD */
add_fpreq(31360, &buffer0[0],1.1920928955078125e-07,-40,&buffer0[407680],2.241683887405088e-06,12,2.2381568669516128e-06,13,&buffer0[188160]);
/* layer 16:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[188160],28,28,40,(const q7_t*) weight18,bias18,scales18,-128,-13,-128,127,&buffer0[0],28,28,120,sbuf);
/* layer 17:DEPTHWISE_CONV_2D */
depthwise_kernel3x3_stride1_inplace_CHW_fpreq(&buffer0[0],28,28,120,(const q7_t*) CHWweight19,offsetBias19,offsetRBias19,scales19,-128,128,-128,127,&buffer0[0],28,28,120,sbuf,-128);
/* layer 18:AVERAGE_POOL_2D */
avg_pooling(&buffer0[0],28,120,28,1,1,1,1,-128,127,&buffer0[94080]);
/* layer 19:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[94080],1,1,120,(const q7_t*) weight20,bias20,scales20,-128,128,-128,127,&buffer0[94200],1,1,10,sbuf);
/* layer 20:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[94200],1,1,10,(const q7_t*) weight21,bias21,scales21,3,128,-128,127,&buffer0[219520],1,1,120,sbuf);
/* layer 21:SE_ELEMENT_MULT_2D */
element_mult_nx1(&buffer0[0],28,28,120,&buffer0[219520],-128,3,-128,-127,128,0.003765581531380985,&buffer0[94080]);
/* layer 22:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[94080],28,28,120,(const q7_t*) weight22,bias22,scales22,-103,128,-128,127,&buffer0[0],28,28,40,sbuf);
/* layer 23:ADD */
add_fpreq(31360, &buffer0[0],1.1920928955078125e-07,-103,&buffer0[188160],2.2381568669516128e-06,13,2.2403025923267705e-06,13,&buffer0[219520]);
/* layer 24:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[219520],28,28,40,(const q7_t*) weight23,bias23,scales23,-128,-13,-128,127,&buffer0[0],28,28,240,sbuf);
/* layer 25:DEPTHWISE_CONV_2D */
depthwise_kernel5x5_stride2_inplace_CHW_fpreq(&buffer0[0],28,28,240,(const q7_t*) CHWweight24,offsetBias24,offsetRBias24,scales24,-128,128,-128,127,&buffer0[0],14,14,240,sbuf,-128);
/* layer 26:AVERAGE_POOL_2D */
avg_pooling(&buffer0[0],14,240,14,1,1,1,1,-128,127,&buffer0[47040]);
/* layer 27:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[47040],1,1,240,(const q7_t*) weight25,bias25,scales25,-128,128,-128,127,&buffer0[47280],1,1,10,sbuf);
/* layer 28:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[47280],1,1,10,(const q7_t*) weight26,bias26,scales26,1,128,-128,127,&buffer0[94080],1,1,240,sbuf);
/* layer 29:SE_ELEMENT_MULT_2D */
element_mult_nx1(&buffer0[0],14,14,240,&buffer0[94080],-128,1,-128,-127,128,0.004900233338694917,&buffer0[47040]);
/* layer 30:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[47040],14,14,240,(const q7_t*) weight27,bias27,scales27,-66,128,-128,127,&buffer0[100352],14,14,64,sbuf);
/* layer 31:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[100352],14,14,64,(const q7_t*) weight28,bias28,scales28,-128,66,-128,127,&buffer0[0],14,14,256,sbuf);
/* layer 32:DEPTHWISE_CONV_2D */
depthwise_kernel5x5_stride1_inplace_CHW_fpreq(&buffer0[0],14,14,256,(const q7_t*) CHWweight29,offsetBias29,offsetRBias29,scales29,-128,128,-128,127,&buffer0[0],14,14,256,sbuf,-128);
/* layer 33:AVERAGE_POOL_2D */
avg_pooling(&buffer0[0],14,256,14,1,1,1,1,-128,127,&buffer0[50176]);
/* layer 34:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[50176],1,1,256,(const q7_t*) weight30,bias30,scales30,-128,128,-128,127,&buffer0[50432],1,1,16,sbuf);
/* layer 35:CONV_2D */
convolve_1x1_s8_ch16_fpreq(&buffer0[50432],1,1,16,(const q7_t*) weight31,bias31,scales31,-3,128,-128,127,&buffer0[112896],1,1,256,sbuf);
/* layer 36:SE_ELEMENT_MULT_2D */
element_mult_nx1(&buffer0[0],14,14,256,&buffer0[112896],-128,-3,-128,-127,128,0.0017640794394537807,&buffer0[50176]);
/* layer 37:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[50176],14,14,256,(const q7_t*) weight32,bias32,scales32,-127,128,-128,127,&buffer0[0],14,14,64,sbuf);
/* layer 38:ADD */
add_fpreq(12544, &buffer0[0],1.1920928955078125e-07,-127,&buffer0[100352],1.1920928955078125e-07,-66,1.1920928955078125e-07,-66,&buffer0[75264]);
/* layer 39:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[75264],14,14,64,(const q7_t*) weight33,bias33,scales33,-128,66,-128,127,&buffer0[0],14,14,192,sbuf);
/* layer 40:DEPTHWISE_CONV_2D */
depthwise_kernel3x3_stride1_inplace_CHW_fpreq(&buffer0[0],14,14,192,(const q7_t*) CHWweight34,offsetBias34,offsetRBias34,scales34,-128,128,-128,127,&buffer0[0],14,14,192,sbuf,-128);
/* layer 41:AVERAGE_POOL_2D */
avg_pooling(&buffer0[0],14,192,14,1,1,1,1,-128,127,&buffer0[37632]);
/* layer 42:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[37632],1,1,192,(const q7_t*) weight35,bias35,scales35,-128,128,-128,127,&buffer0[37824],1,1,16,sbuf);
/* layer 43:CONV_2D */
convolve_1x1_s8_ch16_fpreq(&buffer0[37824],1,1,16,(const q7_t*) weight36,bias36,scales36,5,128,-128,127,&buffer0[87808],1,1,192,sbuf);
/* layer 44:SE_ELEMENT_MULT_2D */
element_mult_nx1(&buffer0[0],14,14,192,&buffer0[87808],-128,5,-128,-127,128,0.0019052247516810894,&buffer0[37632]);
/* layer 45:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[37632],14,14,192,(const q7_t*) weight37,bias37,scales37,-127,128,-128,127,&buffer0[0],14,14,64,sbuf);
/* layer 46:ADD */
add_fpreq(12544, &buffer0[0],1.1920928955078125e-07,-127,&buffer0[75264],1.1920928955078125e-07,-66,1.1920928955078125e-07,-66,&buffer0[100352]);
/* layer 47:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[100352],14,14,64,(const q7_t*) weight38,bias38,scales38,-128,66,-128,127,&buffer0[0],14,14,256,sbuf);
/* layer 48:DEPTHWISE_CONV_2D */
depthwise_kernel7x7_stride1_inplace_CHW_fpreq(&buffer0[0],14,14,256,(const q7_t*) CHWweight39,offsetBias39,offsetRBias39,scales39,-128,128,-128,127,&buffer0[0],14,14,256,sbuf,-128);
/* layer 49:AVERAGE_POOL_2D */
avg_pooling(&buffer0[0],14,256,14,1,1,1,1,-128,127,&buffer0[50176]);
/* layer 50:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[50176],1,1,256,(const q7_t*) weight40,bias40,scales40,-128,128,-128,127,&buffer0[50432],1,1,16,sbuf);
/* layer 51:CONV_2D */
convolve_1x1_s8_ch16_fpreq(&buffer0[50432],1,1,16,(const q7_t*) weight41,bias41,scales41,0,128,-128,127,&buffer0[112896],1,1,256,sbuf);
/* layer 52:SE_ELEMENT_MULT_2D */
element_mult_nx1(&buffer0[0],14,14,256,&buffer0[112896],-128,0,-128,-127,128,0.0017066053114831448,&buffer0[50176]);
/* layer 53:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[50176],14,14,256,(const q7_t*) weight42,bias42,scales42,-126,128,-128,127,&buffer0[0],14,14,64,sbuf);
/* layer 54:ADD */
add_fpreq(12544, &buffer0[0],1.1920928955078125e-07,-126,&buffer0[100352],1.1920928955078125e-07,-66,1.1920928955078125e-07,-66,&buffer0[75264]);
/* layer 55:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[75264],14,14,64,(const q7_t*) weight43,bias43,scales43,-128,66,-128,127,&buffer0[0],14,14,384,sbuf);
/* layer 56:DEPTHWISE_CONV_2D */
depthwise_kernel5x5_stride1_inplace_CHW_fpreq(&buffer0[0],14,14,384,(const q7_t*) CHWweight44,offsetBias44,offsetRBias44,scales44,-128,128,-128,127,&buffer0[0],14,14,384,sbuf,-128);
/* layer 57:AVERAGE_POOL_2D */
avg_pooling(&buffer0[0],14,384,14,1,1,1,1,-128,127,&buffer0[75264]);
/* layer 58:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[75264],1,1,384,(const q7_t*) weight45,bias45,scales45,-128,128,-128,127,&buffer0[75648],1,1,16,sbuf);
/* layer 59:CONV_2D */
convolve_1x1_s8_ch16_fpreq(&buffer0[75648],1,1,16,(const q7_t*) weight46,bias46,scales46,0,128,-128,127,&buffer0[150528],1,1,384,sbuf);
/* layer 60:SE_ELEMENT_MULT_2D */
element_mult_nx1(&buffer0[0],14,14,384,&buffer0[150528],-128,0,-128,-127,128,0.0018231875728815794,&buffer0[75264]);
/* layer 61:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[75264],14,14,384,(const q7_t*) weight47,bias47,scales47,-126,128,-128,127,&buffer0[150528],14,14,96,sbuf);
/* layer 62:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[150528],14,14,96,(const q7_t*) weight48,bias48,scales48,-128,126,-128,127,&buffer0[0],14,14,384,sbuf);
/* layer 63:DEPTHWISE_CONV_2D */
depthwise_kernel5x5_stride1_inplace_CHW_fpreq(&buffer0[0],14,14,384,(const q7_t*) CHWweight49,offsetBias49,offsetRBias49,scales49,-128,128,-128,127,&buffer0[0],14,14,384,sbuf,-128);
/* layer 64:AVERAGE_POOL_2D */
avg_pooling(&buffer0[0],14,384,14,1,1,1,1,-128,127,&buffer0[75264]);
/* layer 65:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[75264],1,1,384,(const q7_t*) weight50,bias50,scales50,-128,128,-128,127,&buffer0[75648],1,1,24,sbuf);
/* layer 66:CONV_2D */
convolve_1x1_s8_ch24_fpreq(&buffer0[75648],1,1,24,(const q7_t*) weight51,bias51,scales51,3,128,-128,127,&buffer0[169344],1,1,384,sbuf);
/* layer 67:SE_ELEMENT_MULT_2D */
element_mult_nx1(&buffer0[0],14,14,384,&buffer0[169344],-128,3,-128,-127,128,0.0017008811701089144,&buffer0[75264]);
/* layer 68:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[75264],14,14,384,(const q7_t*) weight52,bias52,scales52,-128,128,-128,127,&buffer0[0],14,14,96,sbuf);
/* layer 69:ADD */
add_fpreq(18816, &buffer0[0],1.1920928955078125e-07,-128,&buffer0[150528],1.1920928955078125e-07,-126,1.1920928955078125e-07,-126,&buffer0[112896]);
/* layer 70:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[112896],14,14,96,(const q7_t*) weight53,bias53,scales53,-128,126,-128,127,&buffer0[0],14,14,288,sbuf);
/* layer 71:DEPTHWISE_CONV_2D */
depthwise_kernel5x5_stride1_inplace_CHW_fpreq(&buffer0[0],14,14,288,(const q7_t*) CHWweight54,offsetBias54,offsetRBias54,scales54,-128,128,-128,127,&buffer0[0],14,14,288,sbuf,-128);
/* layer 72:AVERAGE_POOL_2D */
avg_pooling(&buffer0[0],14,288,14,1,1,1,1,-128,127,&buffer0[56448]);
/* layer 73:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[56448],1,1,288,(const q7_t*) weight55,bias55,scales55,-128,128,-128,127,&buffer0[56736],1,1,24,sbuf);
/* layer 74:CONV_2D */
convolve_1x1_s8_ch24_fpreq(&buffer0[56736],1,1,24,(const q7_t*) weight56,bias56,scales56,-2,128,-128,127,&buffer0[131712],1,1,288,sbuf);
/* layer 75:SE_ELEMENT_MULT_2D */
element_mult_nx1(&buffer0[0],14,14,288,&buffer0[131712],-128,-2,-128,-127,128,0.0017287431983277202,&buffer0[56448]);
/* layer 76:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[56448],14,14,288,(const q7_t*) weight57,bias57,scales57,-128,128,-128,127,&buffer0[0],14,14,96,sbuf);
/* layer 77:ADD */
add_fpreq(18816, &buffer0[0],1.1920928955078125e-07,-128,&buffer0[112896],1.1920928955078125e-07,-126,1.1920928955078125e-07,-126,&buffer0[75264]);
/* layer 78:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[75264],14,14,96,(const q7_t*) weight58,bias58,scales58,-128,126,-128,127,&buffer0[0],14,14,384,sbuf);
/* layer 79:DEPTHWISE_CONV_2D */
depthwise_kernel7x7_stride2_inplace_CHW_fpreq(&buffer0[0],14,14,384,(const q7_t*) CHWweight59,offsetBias59,offsetRBias59,scales59,-128,128,-128,127,&buffer0[0],7,7,384,sbuf,-128);
/* layer 80:AVERAGE_POOL_2D */
avg_pooling(&buffer0[0],7,384,7,1,1,1,1,-128,127,&buffer0[18816]);
/* layer 81:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[18816],1,1,384,(const q7_t*) weight60,bias60,scales60,-128,128,-128,127,&buffer0[19200],1,1,24,sbuf);
/* layer 82:CONV_2D */
convolve_1x1_s8_ch24_fpreq(&buffer0[19200],1,1,24,(const q7_t*) weight61,bias61,scales61,2,128,-128,127,&buffer0[37632],1,1,384,sbuf);
/* layer 83:SE_ELEMENT_MULT_2D */
element_mult_nx1(&buffer0[0],7,7,384,&buffer0[37632],-128,2,-128,-127,128,0.0017450099112465978,&buffer0[18816]);
/* layer 84:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[18816],7,7,384,(const q7_t*) weight62,bias62,scales62,-128,128,-128,127,&buffer0[56448],7,7,144,sbuf);
/* layer 85:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[56448],7,7,144,(const q7_t*) weight63,bias63,scales63,-128,128,-128,127,&buffer0[0],7,7,576,sbuf);
/* layer 86:DEPTHWISE_CONV_2D */
depthwise_kernel3x3_stride1_inplace_CHW_fpreq(&buffer0[0],7,7,576,(const q7_t*) CHWweight64,offsetBias64,offsetRBias64,scales64,-128,128,-128,127,&buffer0[0],7,7,576,sbuf,-128);
/* layer 87:AVERAGE_POOL_2D */
avg_pooling(&buffer0[0],7,576,7,1,1,1,1,-128,127,&buffer0[28224]);
/* layer 88:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[28224],1,1,576,(const q7_t*) weight65,bias65,scales65,-128,128,-128,127,&buffer0[28800],1,1,36,sbuf);
/* layer 89:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[28800],1,1,36,(const q7_t*) weight66,bias66,scales66,2,128,-128,127,&buffer0[63504],1,1,576,sbuf);
/* layer 90:SE_ELEMENT_MULT_2D */
element_mult_nx1(&buffer0[0],7,7,576,&buffer0[63504],-128,2,-128,-127,128,0.0011730919359251857,&buffer0[28224]);
/* layer 91:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[28224],7,7,576,(const q7_t*) weight67,bias67,scales67,-128,128,-128,127,&buffer0[0],7,7,144,sbuf);
/* layer 92:ADD */
add_fpreq(7056, &buffer0[0],1.1920928955078125e-07,-128,&buffer0[56448],1.1920928955078125e-07,-128,1.1920928955078125e-07,-128,&buffer0[63504]);
/* layer 93:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[63504],7,7,144,(const q7_t*) weight68,bias68,scales68,-128,128,-128,127,&buffer0[0],7,7,576,sbuf);
/* layer 94:DEPTHWISE_CONV_2D */
depthwise_kernel3x3_stride1_inplace_CHW_fpreq(&buffer0[0],7,7,576,(const q7_t*) CHWweight69,offsetBias69,offsetRBias69,scales69,-128,128,-128,127,&buffer0[0],7,7,576,sbuf,-128);
/* layer 95:AVERAGE_POOL_2D */
avg_pooling(&buffer0[0],7,576,7,1,1,1,1,-128,127,&buffer0[28224]);
/* layer 96:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[28224],1,1,576,(const q7_t*) weight70,bias70,scales70,-128,128,-128,127,&buffer0[28800],1,1,36,sbuf);
/* layer 97:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[28800],1,1,36,(const q7_t*) weight71,bias71,scales71,-2,128,-128,127,&buffer0[56448],1,1,576,sbuf);
/* layer 98:SE_ELEMENT_MULT_2D */
element_mult_nx1(&buffer0[0],7,7,576,&buffer0[56448],-128,-2,-128,-127,128,0.0011739147594198585,&buffer0[28224]);
/* layer 99:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[28224],7,7,576,(const q7_t*) weight72,bias72,scales72,-128,128,-128,127,&buffer0[0],7,7,144,sbuf);
/* layer 100:ADD */
add_fpreq(7056, &buffer0[0],1.1920928955078125e-07,-128,&buffer0[63504],1.1920928955078125e-07,-128,1.1920928955078125e-07,-128,&buffer0[28224]);
/* layer 101:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[28224],7,7,144,(const q7_t*) weight73,bias73,scales73,-128,128,-128,127,&buffer0[0],7,7,576,sbuf);
/* layer 102:DEPTHWISE_CONV_2D */
depthwise_kernel5x5_stride1_inplace_CHW_fpreq(&buffer0[0],7,7,576,(const q7_t*) CHWweight74,offsetBias74,offsetRBias74,scales74,-128,128,-128,127,&buffer0[0],7,7,576,sbuf,-128);
/* layer 103:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[0],7,7,576,(const q7_t*) weight75,bias75,scales75,-128,128,-128,127,&buffer0[28224],7,7,240,sbuf);
/* layer 104:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[28224],7,7,240,(const q7_t*) weight76,bias76,scales76,-128,128,-128,127,&buffer0[0],7,7,384,sbuf);
/* layer 105:AVERAGE_POOL_2D */
avg_pooling(&buffer0[0],7,7,384,7,1,1,1,-128,127,&buffer0[18816]);
/* layer 106:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[18816],1,1,384,(const q7_t*) weight77,bias77,scales77,0,128,-128,127,&buffer0[0],1,1,1000,sbuf);
}
void invoke_inf(){
/* layer 0:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[376320],28,28,40,(const q7_t*) weight8,bias8,scales8,-128,-12,-128,127,&buffer0[0],28,28,240,sbuf);
/* layer 1:DEPTHWISE_CONV_2D */
depthwise_kernel5x5_stride1_inplace_CHW_fpreq(&buffer0[0],28,28,240,(const q7_t*) CHWweight9,offsetBias9,offsetRBias9,scales9,-128,128,-128,127,&buffer0[0],28,28,240,sbuf,-128);
/* layer 2:AVERAGE_POOL_2D */
avg_pooling(&buffer0[0],28,240,28,1,1,1,1,-128,127,&buffer0[188160]);
/* layer 3:CONV_2D */
convolve_1x1_s8_fpreq(&buffer0[188160],1,1,240,(const q7_t*) weight10,bias10,scales10,-128,128,-128,127,&buffer0[188400],1,1,10,sbuf);
}
